package com.example.gameunion.DAO;

import com.example.gameunion.Entity.PremiumMembership;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PremiumMembershipDao extends JpaRepository<PremiumMembership,Integer> {
}
