package com.example.gameunion.DAO;

import com.example.gameunion.Entity.Begeni;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BegeniDao extends JpaRepository<Begeni,Integer> {
}
