package com.example.gameunion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GameunionApplication {

    public static void main(String[] args) {
        SpringApplication.run(GameunionApplication.class, args);
    }

}
