package com.example.gameunion.DAO;

import com.example.gameunion.Entity.Report;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReportDao extends JpaRepository<Report,Integer> {
}
